# WebIMP
Repositorio de pruebas para el sitio web del curso de supercómputo para el IMP.


Para activar el repositorio:
    python manage.py migrate
Para lanzar el servidor local
    python manage.py runserver
Para abrir la pagina 
    entrar a un navegador y entrar en localhost:8000/
